/*
i have a loop that continuously updates the board
in the board history i keep track of cell states and lifetypes

here are my checks for refilling the board:
    if the board is empty

then, here are my checks for changing the lifetype:
    it has been a while since the last change
    the board is identical to one of the last 16 boards, lifetype doesn't matter when comparing

after these changes happen, the board will still be evaluated and updated.
*/
use minifb::{Key, Window, WindowOptions};
use rand::seq::SliceRandom;
use rand::Rng;
use std::collections::VecDeque;
use std::thread;
use std::time::{Duration, Instant};

pub(crate) mod consts;
pub(crate) mod display;
pub(crate) mod iterate;
use crate::consts::*;
use crate::display::*;
use crate::iterate::*;

/* Functions to make:
    check_board_history
    refill_board
    update_board
    print_board
*/

fn generate_black_mask(black_mask: &mut Vec<bool>, buffer_width: usize, buffer_height: usize) {
    //this is a mask that makes the drawn pixels rounded, slightly seperated squares.
    //it's a vector of booleans
    //true is black (i think)
    
    let width_of_board_pixels = buffer_width / WIDTH;
    let height_of_board_pixels = buffer_height / HEIGHT;

    for board_y in 0..HEIGHT {
        for board_x in 0..WIDTH {
            let board_pixel_center_x = board_x * width_of_board_pixels + width_of_board_pixels / 2;
            let board_pixel_center_y = board_y * height_of_board_pixels + height_of_board_pixels / 2;
            let radius = width_of_board_pixels as f64 * PERCENTAGE_SIZE_REDUCTION / 2.0;

            let circle_center_distance_from_board_pixel_center = radius * PERCENTAGE_ROUNDED_CORNERS;

            //iterate over the pixels in the section of the screen for the current board pixel
            for buffer_y in (board_y * height_of_board_pixels)..((board_y + 1) * height_of_board_pixels) {
                for buffer_x in (board_x * width_of_board_pixels)..((board_x + 1) * width_of_board_pixels) {

                    let distance = (board_pixel_center_x as f64 - buffer_x as f64).abs().max(
                        (board_pixel_center_y as f64 - buffer_y as f64).abs()
                    );
                    if distance > radius {
                        black_mask[buffer_y * buffer_width + buffer_x] = true;
                    } else {
                        black_mask[buffer_y * buffer_width + buffer_x] = false;
                    }
                    //top left corner
                    let tl_circle_center_x = board_pixel_center_x as f64 - circle_center_distance_from_board_pixel_center;
                    let tl_circle_center_y = board_pixel_center_y as f64 - circle_center_distance_from_board_pixel_center;
                    let tl_distance = ((tl_circle_center_x - buffer_x as f64).powi(2) + (tl_circle_center_y - buffer_y as f64).powi(2)).sqrt();
                    //if the current pixel is outside the circle and to the top left of the circle, make the pixel black
                    if tl_distance > (1.0-PERCENTAGE_ROUNDED_CORNERS) * radius && buffer_x < tl_circle_center_x as usize && buffer_y < tl_circle_center_y as usize {
                        black_mask[buffer_y * buffer_width + buffer_x] = true;
                    }
                    //top right corner
                    let tr_circle_center_x = board_pixel_center_x as f64 + circle_center_distance_from_board_pixel_center;
                    let tr_circle_center_y = board_pixel_center_y as f64 - circle_center_distance_from_board_pixel_center;
                    let tr_distance = ((tr_circle_center_x - buffer_x as f64).powi(2) + (tr_circle_center_y - buffer_y as f64).powi(2)).sqrt();
                    //if the current pixel is outside the circle and to the top right of the circle, make the pixel black
                    if tr_distance > (1.0-PERCENTAGE_ROUNDED_CORNERS) * radius && buffer_x > tr_circle_center_x as usize && buffer_y < tr_circle_center_y as usize {
                        black_mask[buffer_y * buffer_width + buffer_x] = true;
                    }
                    //bottom left corner
                    let bl_circle_center_x = board_pixel_center_x as f64 - circle_center_distance_from_board_pixel_center;
                    let bl_circle_center_y = board_pixel_center_y as f64 + circle_center_distance_from_board_pixel_center;
                    let bl_distance = ((bl_circle_center_x - buffer_x as f64).powi(2) + (bl_circle_center_y - buffer_y as f64).powi(2)).sqrt();
                    //if the current pixel is outside the circle and to the bottom left of the circle, make the pixel black
                    if bl_distance > (1.0-PERCENTAGE_ROUNDED_CORNERS) * radius && buffer_x < bl_circle_center_x as usize && buffer_y > bl_circle_center_y as usize {
                        black_mask[buffer_y * buffer_width + buffer_x] = true;
                    }
                    //bottom right corner
                    let br_circle_center_x = board_pixel_center_x as f64 + circle_center_distance_from_board_pixel_center;
                    let br_circle_center_y = board_pixel_center_y as f64 + circle_center_distance_from_board_pixel_center;
                    let br_distance = ((br_circle_center_x - buffer_x as f64).powi(2) + (br_circle_center_y - buffer_y as f64).powi(2)).sqrt();
                    //if the current pixel is outside the circle and to the bottom right of the circle, make the pixel black
                    if br_distance > (1.0-PERCENTAGE_ROUNDED_CORNERS) * radius && buffer_x > br_circle_center_x as usize && buffer_y > br_circle_center_y as usize {
                        black_mask[buffer_y * buffer_width + buffer_x] = true;
                    }

                }
            }
        }
    }
}

fn main() {
    //thread::sleep(Duration::from_millis(2000));
    let mut rng = rand::thread_rng();

    //show cursor (ansi sequence)
    //print!("\x1b[?25h");

    //wait 2 seconds

    let mut state_history: VecDeque<Vec<Vec<usize>>> =
        VecDeque::from(vec![
            vec![vec![0; WIDTH as usize]; HEIGHT as usize];
            HISTORY_LENGTH
        ]);
    let mut type_history: VecDeque<usize> = VecDeque::from(vec![0; HISTORY_LENGTH]);
    let mut limited_life_timer: usize = 0;

    let mut colour_palette: [u32; 6];
    let mut old_colour_palette: [u32; 6];

    
    let window_width = WIDTH*DETAIL_MULTIPLIER;
    let window_height = HEIGHT*DETAIL_MULTIPLIER;
    let buffer_width = window_width;
    let buffer_height = window_height;
    
    
    let options = WindowOptions {
        resize: true,
        ..WindowOptions::default()
    };
    let mut window = Window::new("Screensaver", window_width, window_height, options).unwrap_or_else(|e| {
        panic!("{}", e);
    });
    
    let mut black_mask: Vec<bool> = vec![false; buffer_width * buffer_height];
    generate_black_mask(&mut black_mask, buffer_width, buffer_height);

    let mut current: Instant;
    let mut buffer: Vec<u32> = vec![0; (buffer_width * buffer_height) as usize];

    while window.is_open() && !window.is_key_down(Key::Escape) {
        current = Instant::now();

        let mut new_board = state_history[0].clone();
        let mut new_type: usize = type_history[0];

        match check_board_history(&state_history, &limited_life_timer) {
            //0: board is empty, refill it and change lifetype
            //1: board is identical to one of the last 16 boards, change lifetype
            //2: board has been the same for a while, change lifetype
            1 | 2 => {
                limited_life_timer = 150 + rng.gen_range(0..250); //also reset limited_life_timer

                //new_type = rng.gen_range(0, LIFE_REF.len());
                //check if the next board iteration will be empty with this type, and if so, change it.
                //keep changing and checking until the next board will not be empty
                //shuffled range of 0 to life_ref.len() - 1
                let mut shuffled_range: Vec<usize> = (0..LIFE_REF.len()).collect();
                shuffled_range.shuffle(&mut rng);

                for lifetype in shuffled_range {

                    let empty = {
                        //update board 5 times
                        let mut b = update_board(&new_board, &lifetype, &false);
                        for _ in 0..10 {
                            b = update_board(&b, &lifetype, &false);
                        }
                        b
                    }
                        .iter()
                        .flatten()
                        .all(|&x| x != 1);
                    if !empty {
                        new_type = rng.gen_range(0..LIFE_REF.len());
                        break;
                    }
                }
            }
            0 => {
                limited_life_timer = 150 + rng.gen_range(0..250); //also reset limited_life_timer
                new_type = rng.gen_range(0..LIFE_REF.len());

                //previous board is empty, refill after doing all the other stuff first
                new_board = refill_board(&new_board, &type_history[0]); //see if i can remove this clone later
            }
            _ => {}
        }
        //update the board
        new_board = update_board(
            &new_board,
            &type_history[0],
            &(new_type != type_history[0]), // && new_type - 3 < 3),
        ); //see if i can remove this clone later

        //update the history and limited life timer
        state_history.pop_back();
        state_history.push_front(new_board);

        type_history.pop_back();
        type_history.push_front(new_type);

        limited_life_timer -= 1;
        colour_palette = COLOUR_REF[type_history[0]];
        old_colour_palette = COLOUR_REF[type_history[1]];


        //print the board
        for blend in 0..DELAY_BLUR_MS {
            print_board(
                &state_history[0],
                &state_history[1],
                colour_palette,
                old_colour_palette,
                &mut buffer,
                buffer_width,
                buffer_height,
                &black_mask,
                blend as f32 / DELAY_BLUR_MS as f32,
            );
            window.update_with_buffer(&buffer, buffer_width, buffer_height).unwrap();
            thread::sleep(Duration::from_millis(2));
        }
        print_board(
            &state_history[0],
            &state_history[1],
            colour_palette,
            old_colour_palette,
            &mut buffer,
            buffer_width,
            buffer_height,
            &black_mask,
            1.0,
        );
        window.update_with_buffer(&buffer, buffer_width, buffer_height).unwrap();

        let duration = current.elapsed();

        thread::sleep(Duration::from_millis(
            DELAY_MS - (duration.as_millis() as u64).min(DELAY_MS-DELAY_BLUR_MS),
        ));

    }
}
